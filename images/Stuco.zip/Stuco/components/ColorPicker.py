from flet import *
from utils.DataManager import DataObj

themeObj = DataObj("data/theme.json")
ThemeColors = [
["Rose Quartz", "#F48FB1"],
["Twilight Lavender", "#9575CD"],
["Arctic Glass", "#0097A7"],
["Midnight Cobalt", colors.INDIGO_900],
["Slate Monolith", "#90A4AE"],
["Forest Canopy", "#1B3022"],
["Emerald Glade", "#0A5E4D"],
["Electric Lime", "#C0FF00"],
["Honey Glow", "#FFE082"],
["Coral Care", "#FF7043"],
["Autumn Leaf", colors.ORANGE_800],
["Crimson Pulse", colors.RED_900]
]

class ColorPicker(Container):
	def __init__(self , color_list , grid_num , page):
		super().__init__()
		self.page = page
		self.border_width = 2
		self.padding = padding.only(bottom = 12)
		
		colors = [color_list[i:i + grid_num] for i in range(0, len(color_list), grid_num)]
		
		col = Column()
		self.colorItems = []
		
		for row_ in colors:
			row = Row(alignment = MainAxisAlignment.SPACE_EVENLY)
			for col_ in row_:
				is_active = col_[1] == page.session.get("themeColor")
				item = self.ColorItem(col_[1] , is_active , col_[0])
				row.controls.append(item)
				self.colorItems.append(item)
			col.controls.append(row)
		
		self.content = col
	
	def ColorItem(self , color , is_active , tip):
		cont = Container(
		bgcolor = color,
		border_radius = 12,
		height = 38,
		width = 38,
		scale=1.2 if is_active else 1.0,
		border = border.all(self.border_width, colors.ON_SURFACE) if is_active else None,
		on_click = self.change_theme,
		animate=animation.Animation(300, AnimationCurve.EASE_OUT),
		shadow=BoxShadow(blur_radius=8, color= colors.BLACK12),
		tooltip = tip
		)
		
		return cont
	
	def change_theme(self , e):		
		for item in self.colorItems:
			item.border = None
			item.scale = 1
		
		e.control.border = border.all(self.border_width, colors.ON_SURFACE)
		e.control.scale = 1.2
		
		theme_color = e.control.bgcolor
		theme_name = e.control.tooltip
		
		self.page.snack_bar = SnackBar(
		content= Text(f"Theme changed to {theme_name}"),
		action="OK")
		self.page.snack_bar.open = True
		
		themeObj.update("themeColor" , theme_color)
		self.page.session.set("themeColor" , theme_color)
		self.page.theme = Theme(color_scheme_seed = theme_color , font_family = self.page.session.get("themeFont"))
		
		self.page.update()