from flet import *
from components.NavBar import NavBar
from components.Customs import SettingsIconTile, SettingsPanel, GradText
from components.ColorPicker import ColorPicker, ThemeColors
from components.RectGraph import RectGraph
from utils.DataManager import DataObj


themeObj = DataObj("data/theme.json")

def docs_view(page):
	col = Column(scroll = ScrollMode.ADAPTIVE , expand = True)
	
	def xyz(e):
		page.bottom_sheet.open = True
		return page.update()
	
	def xy(e):
		return page.loader.load("Sample..." , 5)
	
	datx = [100,200,300,200,100,500,700,400,200]
	daty = [["Mon" , "Tue" , "Wed"] , ["Mon" , "Tue" , "Wed"]]
		
	btn = ElevatedButton(text = "Bottom" , on_click = xyz)
	btn2 = ElevatedButton(text = "Load" , on_click = xy)
	col.controls.extend([
	Text("Welcome to the Docs Page!", size=30),
	btn,
	btn2,
	RectGraph(datx , daty , "red")
	])
	
	return View(
		route="/docs",
		controls = [col],
		bottom_appbar = BottomAppBar(content = NavBar(page))
		)