import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# --- Configuration ---
sender_email = "sparknexus16@gmail.com"
receiver_email = "shashankpathak963@gmail.com"
app_password = "lcoewknnbvcifihn"  # No spaces

# --- Create the Message ---
message = MIMEMultipart("alternative")
message["Subject"] = "Check out this HTML Email!"
message["From"] = sender_email
message["To"] = receiver_email

# Create the plain-text and HTML version of your message
text = "Hi! This is a plain text version of the email."
html = """
<html>
  <body style="font-family: Arial, sans-serif; color: #333;">
    <h1 style="color: #4A90E2;">Hello from Python!</h1>
    <p>This is a <b>custom HTML</b> email sent using <i>smtplib</i>.</p>
    <table border="1" style="border-collapse: collapse; width: 100%;">
      <tr style="background-color: #f2f2f2;">
        <th>Feature</th>
        <th>Status</th>
      </tr>
      <tr>
        <td>HTML Support</td>
        <td>✅ Active</td>
      </tr>
    </table>
  </body>
</html>
"""

# Turn these into plain/html MIMEText objects
part1 = MIMEText(text, "plain")
part2 = MIMEText(html, "html")

# Add HTML/plain-text parts to MIMEMultipart message
# The last part added is the one the recipient sees by default
message.attach(part1)
message.attach(part2)

# --- Send the Email ---
try:
    # Connect to Gmail's SMTP server
    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
        server.login(sender_email, app_password)
        server.sendmail(sender_email, receiver_email, message.as_string())
    print("Email sent successfully!")
except Exception as e:
    print(f"Error: {e}")
