from flet import *
from utils.DataManager import DataObj
import time

themeObj = DataObj("data/theme.json")

def GradText(txt = "Sample" , size = 14):
	return ShaderMask(
		content=Text(txt, size=size, weight="bold"),
		blend_mode="srcIn",
		shader=LinearGradient(
			begin=alignment.top_left,
			end=alignment.bottom_right,	
			colors=[colors.PRIMARY , colors.ON_SURFACE]))

def InputTitle(title = '' , size = 12 ,  control = None):
	title_label = Text(title , size = size , color = colors.ON_SURFACE_VARIANT , weight = "bold")
	return Column(controls = [title_label , control] , spacing = 2)

def TopAppBar(text = "" , icon = None , func = None):
	return Row([GradText(text, 32) , IconButton(icons.CLOSE_ROUNDED , icon_size = 30 , icon_color = colors.ON_SURFACE , on_click = func)] , alignment = MainAxisAlignment.SPACE_BETWEEN) if icon else Row([GradText(text, 32)] , alignment = MainAxisAlignment.SPACE_BETWEEN)

def GlassPanel(div):
	wrapper = Container(
	content = div,
	padding = 6,
	bgcolor = colors.with_opacity(0.18 , colors.SURFACE),
	border = border.all(1, colors.with_opacity(0.15 , colors.ON_SURFACE)),
	border_radius = 8,
	gradient = LinearGradient(
	begin = alignment.top_left,
	end = alignment.top_right,
	colors= [colors.PRIMARY , colors.SECONDARY , colors.PRIMARY])
	)
	
	return wrapper
	
def SettingsPanel(div):
	wrapper = Container(
	content = div,
	padding = padding.only(top=5 , bottom=5 , left= 12 , right = 12),
	bgcolor = colors.SURFACE,
	border = border.all(1, colors.OUTLINE_VARIANT),
	border_radius = 6
	)
	
	return wrapper

def SettingsTile(content):
	div = Row(alignment = MainAxisAlignment.SPACE_BETWEEN)
	div.controls.extend(content)
	return div

def SettingsIconTile(txt , icon , path , page):
	def changeNav(e):
		page.go(path)
		
	tile = SettingsPanel(
	SettingsTile([
	Row([
	Icon(icon , size = 25 , color = colors.PRIMARY),
	Text(txt , size = 18)
	]),
	Icon(icons.CHEVRON_RIGHT , size = 25 , color = colors.TERTIARY)
	]))
	tile.height = 50
	tile.on_click = changeNav
	return tile

class FakeInput(Container):
	def __init__(self , page , text = "" , suffix_icon = None , func = None):
		super().__init__()
		self.page = page
		self.padding = padding.only(left = 15 , right = 5 , top = 2 , bottom = 2)
		self.bgcolor = colors.with_opacity(0.1 , colors.PRIMARY_CONTAINER)
		self.border = border.all(1, colors.OUTLINE_VARIANT)
		self.border_radius = 14
		self.on_click = func
		self.text = text
		
		self.txt = Text("                 " , size = 12 , color = colors.ON_SURFACE_VARIANT)
		self.icon = IconButton(suffix_icon , icon_color = colors.ON_SURFACE_VARIANT , disabled = True)
	
		div = Container(
		content = Row(
			alignment = MainAxisAlignment.SPACE_BETWEEN,
			controls = [self.txt , self.icon]
		))
		
		self.content = div
	
	@property
	def value(self):
		return self.text
		
	def update_text(self , text = "Updated!!!"):
		self.txt.size = 16
		self.txt.color = colors.ON_SURFACE
		self.txt.value = text

class Loader(Container):
	def __init__(self , page):
		super().__init__()
		self.page = page
		self.time = time
		self.txt = Text("" , size = 18)
		
		self.bgcolor = colors.with_opacity(0.5 , colors.SURFACE)
		self.visible = False
		self.height = page.height
		self.width = page.width
		self.alignment = alignment.center
		
		row = Row(controls = [
		ProgressRing(width=40, height=40, stroke_width=4),
		self.txt] ,
		spacing = 10
		)
		
		self.content = Stack([Container(
		content = row ,
		padding = padding.only(left = 15 , right = 15 , top = 10 , bottom = 10) ,
		bgcolor = colors.SURFACE_VARIANT,
		border_radius = 10,
		height = int(page.height * 0.105),
		width = int(page.width * 0.9))])
	
	def load(self , text = "" , time_ = 0.5):
		self.txt.value = text
		self.visible = True
		self.page.update()
		time.sleep(time_)
		self.visible = False
		self.page.update()