import sqlite3
from datetime import datetime, timedelta

def formatt(minutes):
	hrs = int(minutes // 60)
	mins = int(minutes % 60)
	extra = ""
	if mins:
		extra = f" {mins}m"
	return f"{hrs}h" + extra

class Analyse:
	def __init__(self , data):
		self.data = data
	
	def get_time_period(self , i):
		time_map = {
		(0, 360): "Early Morning",
		(360, 720): "Morning",
		(720, 1080): "Afternoon",
		(1080 , 1440): "Night"}
		
		return next((val for (low, high), val in time_map.items() if low <= i < high), "Unknown")
	
	def performance_report(self):
		total_mins = 0
		quality_mins = 0
		days = []
		for row in self.data:
			mins = row[3] - row[2]
			total_mins += mins
			quality_mins += mins * row[4] / 10
			if not row[1] in days:
				days.append(row[1])
		
		return {
			"total": formatt(total_mins),
			"quality": formatt(quality_mins),
			"daily_avg": formatt(total_mins/len(days) if len(days) > 0 else 0),
			"session_avg" : formatt(total_mins / len(self.data) if len(self.data) > 0 else 0)
			}
	
	def check_burnout(self):
		pass
	
	def most_productive_period(self):
		raw_data = {"Early Morning" : [0,0] , "Morning" : [0,0] , "Afternoon" : [0,0] , "Night" : [0,0]}
		for row in self.data:
			time_period = self.get_time_period(row[2])
			focus = row[4]
			raw_data[time_period][0] += focus
			raw_data[time_period][1] += 1
		
		result = []
		for dat in raw_data:
			result.append([dat , raw_data[dat][0] / raw_data[dat][1] if raw_data[dat][1] != 0 else 0])
		
		return sorted(result , key=lambda x: x[1] , reverse = True)
		
		
	def most_productive_type(self):
		raw_data = {}
		for row in self.data:
			study_type = row[5]
			focus = row[4]
			if raw_data.get(study_type):
				raw_data[study_type][0] += focus
				raw_data[study_type][1] += 1
			else:
				raw_data[study_type] = [focus , 1]
				
		result = []
		for dat in raw_data:
			result.append([dat , raw_data[dat][0] / raw_data[dat][1] if raw_data[dat][1] != 0 else 0])
		
		return sorted(result , key=lambda x: x[1] , reverse = True)
		
	def recommend(self):
		pass
		

class TimeManager:
	def __init__(self , file):
		self.conn = sqlite3.connect(file)
		self.cursor = self.conn.cursor()
		self.initiate()
	
	def initiate(self):
		self.cursor.execute('''CREATE TABLE IF NOT EXISTS TimeData (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	date TEXT,
	start_time INTEGER,
	end_time INTEGER,
	focus_rating INTEGER,
	study_type TEXT,
	user_note TEXT
)''')
		self.conn.commit()
	
	
	def add(self , date = "2026-02-12" , start = 300 , end = 450 , focus_rating = 8 , study_type = "Reading" , user_note = "Average"):
		if not end > start:
			return
		query = '''INSERT INTO TimeData (date, start_time , end_time , focus_rating, study_type , user_note) 
            VALUES (?, ?, ?, ?, ? , ?)'''
		self.save(query , (date , start , end , focus_rating , study_type , user_note))
		
	
	def get(self , date = "2026-02-12"):
		query = '''SELECT * FROM TimeData WHERE date = ?'''
		self.cursor.execute(query , (date,))
		return self.cursor.fetchall()
	
	def get_info(self , data = []):
		time_studied = 0
		focus_rating = 0
		if data:
			time_studied += sum(row[3] - row[2] for row in data)
			focus_rating = sum(row[4] for row in data) / len(data)
		
		return formatt(time_studied) , focus_rating
	
	def get_graph_data(self , data = []):
		if not data:
			return {}
		
		totals = {}
		for row in data:
			duration = row[3] - row[2]
			focus = row[4]
			date = row[1]
			
			if date not in totals:
				totals[date] = [duration , focus , 1]
			else:
				totals[date][0] += duration
				totals[date][1] += focus
				totals[date][2] += 1
		
		parsed_dates = [datetime.strptime(row[1], '%Y-%m-%d') for row in data]
		start_date = min(parsed_dates)
		end_date = max(parsed_dates)
		
		current_date = start_date
		
		output = {}
		while current_date <= end_date:
			date = current_date.strftime('%Y-%m-%d')
			if date in totals:
				stats = totals[date]
				avg_focus = stats[1] / stats[2]
				output[date] = (stats[0], avg_focus)
			else:
				output[date] = (0, 0)
			current_date += timedelta(days=1)
			
		return output
		
	def get_by_range(self, period="week" , offset = 0):
		options = {
		"week": "days",
		"month": "month",
		"year": "year"}
		interval = options.get(period, "days")
		multiplier = 1
		if period == "week":
			multiplier = 7
		
		start_offset = f"-{multiplier *(offset + 1)} {interval}"
		end_offset = f"-{multiplier *offset} {interval}" if offset > 0 else "now"
		
		query = f'''
	SELECT * FROM TimeData
	WHERE date >= date('now', ?) 
	AND date < date('now', ?)
	ORDER BY date DESC
	'''
	
		end_param = 'localtime' if end_offset == "now" else end_offset
		
		self.cursor.execute(query, (start_offset, end_param))
		return self.cursor.fetchall()
	
	def get_yearly_data(self):
		result = []
		for x in range(12):
			result.append(self.get_info(self.get_by_range("month" , x)))
		return result[::-1]
	
	def analysis(self):
		pass
	
	def delete(self , id):
		query = '''DELETE FROM TimeData WHERE id = ?'''
		self.save(query , (id,))
	
	def delete_all(self):
		query = '''DELETE FROM TimeData'''
		self.save(query , ())
		
	
	def save(self , query , values):
		try:
			self.cursor.execute(query , values)
			self.conn.commit()
		except:
			pass
			
	def __enter__(self):
		return self

	def __exit__(self, exc_type, exc_val, exc_tb):
		self.conn.close()

#with TimeManager("sessions.db") as tm:
#	s = tm.get_by_range("week" , 0)
#	
#	an = Analyse(s)
#	print(an.most_productive_period())
#	print(an.most_productive_type())
#	print(an.performance_report())
#	
#	#print(tm.get_yearly_data())
#	print(tm.get_graph_data(s))