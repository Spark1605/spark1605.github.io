from flet import *
from components.NavBar import NavBar
from components.Customs import GradText , GlassPanel , FakeInput , TopAppBar , InputTitle , SettingsPanel
from utils.DataManager import DataObj
from utils.TimeManager import TimeManager

from datetime import datetime as dt


themeObj = DataObj("data/theme.json")

def go_to_add_record_view(e):
	e.page.go("/add_record")

def back_home(e):
	e.page.go("/")

def home_view(page):
	col = Column(scroll = ScrollMode.ADAPTIVE , expand = True)
	
	col.controls.extend([
	TopAppBar("Stuco" , False)
	])
	
	actionBtn = FloatingActionButton(
		icon= icons.ADD,
		bgcolor= colors.ON_SURFACE_VARIANT,
		content= Icon(icons.ADD, color=colors.SURFACE),
		on_click=go_to_add_record_view,
	)
	
	return View(
		route="/",
		controls = [col],
		bottom_appbar = BottomAppBar(content = NavBar(page)),
		floating_action_button = actionBtn
		)

def add_record_view(page):
	now = dt.now()
	form_values = {
	"date" : "",
	"start" : True,
	"start_mins" : 0,
	"end_mins" : 0
	}
	
	def go_to(e):
		page.go("/")
	
	def set_date(e):
		form_values["date"] = date_picker.value.strftime("%Y-%m-%d")
		dateInp.update_text(str(form_values["date"]))
		page.update()
	
	def set_time(e):
		time = (time_picker.value.hour * 60) + time_picker.value.minute
		if form_values["start"]:
			form_values["start_mins"] = time
			start_timeInp.update_text(str(f'{time//60}:{time%60}'))
		else:
			form_values["end_mins"] = time
			end_timeInp.update_text(str(f'{time//60}:{time%60}'))
		page.update()
	
	def save_form(e):
		review = studyReview.content.value
		intensity = focusIntensity.value
		type = studyType.content.value
		s_mins = form_values["start_mins"]
		e_mins = form_values["end_mins"]
		
		if ((form_values["date"] and type) and intensity) and (s_mins < e_mins):
			saveForm = TimeManager("sessions.db")
			saveForm.add(form_values["date"] , s_mins, e_mins , intensity , type , review)
			page.loader.load("Saving..." , 0.5)
			page.go("/")
			
		else:
			page.snack_bar = SnackBar(
			content= Text("Error filling the form , enter valid arguments.", weight = "bold"),
			action="OK",
			bgcolor = colors.ERROR)
			page.snack_bar.open = True
		page.update()
	
	date_picker = DatePicker(
	on_change= set_date,
	first_date=dt(2000, 1, 1),
	last_date=dt(now.year , now.month , now.day),)
	
	time_picker = TimePicker(
	on_change = set_time
    )
	
	page.overlay.extend([date_picker , time_picker])
	
	def pick_date(e):
		return date_picker.pick_date()
	
	def pick_time(e):
		form_values["start"] = "Start" in e.control.value
		return time_picker.pick_time()
	
	form = Column(controls = [] , scroll  = ScrollMode.ADAPTIVE)
	col = SettingsPanel(form)
	col.padding = padding.only(left = 25 , right = 25 , top = 15  , bottom = 15)
	col.border_radius = 20
	
	topAppBar = TopAppBar("Add Session" , True , go_to)
	
	dateInp = FakeInput(page , "Date" , icons.ARROW_DROP_DOWN , pick_date)
	start_timeInp = FakeInput(page , "Start From" , icons.ARROW_DROP_DOWN , pick_time)
	end_timeInp = FakeInput(page , "End At    " , icons.ARROW_DROP_DOWN , pick_time)
	
	timeRow = Row(alignment = MainAxisAlignment.SPACE_BETWEEN,
	controls = [
	InputTitle("Start" , 14 , start_timeInp), 
	InputTitle("End" , 14 , end_timeInp)]
	)
	
	studyType = SettingsPanel(Dropdown(
		label="",
		border_radius = 14,
		border = InputBorder.NONE,
		options=[
			dropdown.Option(text = "Reading"),
			dropdown.Option(text = "Solving Numericals"),
			dropdown.Option(text = "Revision"),
			dropdown.Option(text = "Mock-Test"),
			dropdown.Option(text = "Watching Lecture")
	]))
	studyType.bgcolor = colors.with_opacity(0.1 , colors.PRIMARY_CONTAINER)
	studyType.border_radius = 14
	
	focusIntensity = Slider(min = 1 , max = 10 , value = 5 ,  label = "{value}" , divisions = 9)
	
	studyReview = SettingsPanel(TextField(hint_text = "What was your review of this session?" , border = InputBorder.NONE , multiline = True , min_lines = 3 , max_lines = 3 , border_radius = 14 , ))
	studyReview.bgcolor = colors.with_opacity(0.1 , colors.PRIMARY_CONTAINER)
	studyReview.border_radius = 14
	
	saveBtn = FilledButton("Save Session",
	on_click=save_form,
	style=ButtonStyle(
	color=colors.SURFACE,
	bgcolor= colors.PRIMARY_CONTAINER,
	shape=RoundedRectangleBorder(radius=14),
	padding=20),
	width=float("inf"))
	
	form.controls.extend([
	InputTitle("Date" , 14 , dateInp),
	timeRow,
	InputTitle("Study Type" , 14 , studyType),
	InputTitle("Focus Intensity" , 14 ,focusIntensity),
	InputTitle("Review" , 14 , studyReview),
	saveBtn
	])
	
	return View(
		route="/add_record",
		controls = [topAppBar , col]
		)