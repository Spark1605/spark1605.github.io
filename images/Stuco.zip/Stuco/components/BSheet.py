from flet import *


class BSheet(Container):
	def __init__(self , page):
		super().__init__()
		self.page = page
		
		self.padding = 20
		
		title = Text("Have a blasttttt!" , size = 25 , weight = "bold")
		
		self.content = Column(controls = [title , Divider()] , tight = True)