from flet import *
from components.NavBar import NavBar
from components.Customs import SettingsIconTile, SettingsPanel, GradText , TopAppBar
from components.ColorPicker import ColorPicker, ThemeColors

from utils.DataManager import DataObj
from utils.TimeManager import TimeManager


themeObj = DataObj("data/theme.json")

def stats_view(page):
	col = Column(scroll = ScrollMode.ADAPTIVE , expand = True)
	
	col.controls.extend([
	TopAppBar("Statistics" , False),
	])
	
	return View(
		route="/stats",
		controls = [col],
		bottom_appbar = BottomAppBar(content = NavBar(page))
		)