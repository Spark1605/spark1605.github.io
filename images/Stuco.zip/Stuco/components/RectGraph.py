from flet import *

class GraphBar(Container):
    def __init__(self, val, height_ratio, color):
        super().__init__()
        self.val = val
        self.bgcolor = color
        self.border_radius = border_radius.only(top_left=10, top_right=10)
        self.width = 40
        self.height = 0  # Start at 0 for animation
        self.animate_size = animation.Animation(800, AnimationCurve.OUT_QUAD)
        self.tooltip = f"{val // 60}h {val % 60}m"
        self.final_height = height_ratio * 300  # Scale to container height

class RectGraph(Column):
    def __init__(self, data_x, data_y, bar_color):
        super().__init__()
        self.data_x = data_x  # List of lists
        self.data_y = data_y  # List of lists
        self.index = 0
        self.bar_color = bar_color
        
        # Header for Summary
        self.title_text = Text(size=20, weight="bold")
        self.date_range = Text(size=14, color=colors.GREY_500)
        
        # Bar Container
        self.chart_row = Row(
            alignment=MainAxisAlignment.SPACE_EVENLY,
            vertical_alignment=CrossAxisAlignment.END,
            height=300,
        )
        
        self.controls = [
            Column([self.title_text, self.date_range], horizontal_alignment="center"),
            GestureDetector(
                on_pan_update=self.on_swipe,
                content=Container(
                    content=self.chart_row,
                    padding=10,
                    border=border.only(bottom=BorderSide(1, "grey"))
                )
            )
        ]

    def did_mount(self):
        self.update_graph()

    def update_graph(self):
        current_x = self.data_x[self.index]
        current_y = self.data_y[self.index]
        
        total_minutes = sum(current_x)
        self.title_text.value = f"{total_minutes // 60}h {total_minutes % 60}m"
        self.date_range.value = f"Period: {current_y[0]} - {current_y[-1]}"
        
        self.chart_row.controls.clear()
        bars = []
        for val in current_x:
            # Assuming 1400 is your max scale from Kivy code
            ratio = val / 1400 
            bar = GraphBar(val, ratio, self.bar_color)
            bars.append(bar)
            self.chart_row.controls.append(bar)
        
        self.update()
        
        # Trigger Animation after render
        for bar in bars:
            bar.height = bar.final_height
        self.update()

    def on_swipe(self, e: DragUpdateEvent):
        if e.delta_x > 10: # Swipe Right
            if self.index > 0:
                self.index -= 1
                self.update_graph()
        elif e.delta_x < -10: # Swipe Left
            if self.index < len(self.data_x) - 1:
                self.index += 1
                self.update_graph()