from flet import *
from components.NavBar import NavBar
from components.Customs import SettingsTile , SettingsIconTile, SettingsPanel, GradText , GlassPanel , TopAppBar
from components.ColorPicker import ColorPicker, ThemeColors
from utils.DataManager import DataObj


themeObj = DataObj("data/theme.json")

def settings_view(page):
	topAppBar = TopAppBar("Settings" , False)
	
	themeTile = SettingsIconTile("Theme" , icons.FORMAT_PAINT , "/settings/theme" , page)
	profileTile = SettingsIconTile("Profile" , icons.ACCOUNT_CIRCLE , "/settings/theme" , page)
	dataTile = SettingsIconTile("Export/Load Data" , icons.SAVE , "/settings/theme" , page)
	infoTile = SettingsIconTile("Info" , icons.INFO , "/settings/theme" , page)
	
	col = Column(scroll = ScrollMode.ADAPTIVE , expand = True)
	col.controls.extend([
	topAppBar,
	themeTile,
	profileTile,
	dataTile,
	infoTile
	])
	
	return View(
		route="/settings",
		controls = [col],
		bottom_appbar = BottomAppBar(content = NavBar(page))
		)

def theme_view(page):
	def toggleDark(e):
		page.theme_mode = ThemeMode.DARK if e.control.value else ThemeMode.LIGHT
		is_dark = page.theme_mode == ThemeMode.DARK
		themeObj.update("dark" , is_dark)
		page.session.set("is_dark" , is_dark)
		page.update()
	
	def set_themeFont(e):
		font = e.control.value
		page.theme = Theme(font_family= font , color_scheme_seed = page.session.get("themeColor"))
		themeObj.update("themeFont" , font)
		page.session.set("themeFont" , font)
		page.update()
	
	def go_to(e):
		return page.go("/settings")

	col = Column(scroll = ScrollMode.ADAPTIVE , expand = True , spacing = 10)
	
	topAppBar = TopAppBar("Theme" , True , go_to)
	
	themeMode = SettingsPanel(
	SettingsTile([
	Text("Enable Dark Mode" , size = 17),
	Switch(on_change = toggleDark , scale = 0.8 , value = page.session.get("is_dark"))
	]))
	
	themeFont = SettingsPanel(
	SettingsTile([
	Text("Set Theme Font Style" , size = 17),
	Dropdown(
		label=page.session.get("themeFont"),
		width=100,
		scale = 0.8,
		on_change = set_themeFont,
		options=[
			dropdown.Option(text = "Default" , key = ""),
			dropdown.Option(text = "Ariana Violeta" , key = "ariana"),
			dropdown.Option(text = "Believe It" , key = "believe"),
			dropdown.Option(text = "Arial" , key = "arial"),
			dropdown.Option(text = "Cursive" , key = "curly")
	])
	]))
	
	themeCol = SettingsPanel(Column([
	Text("Select Theme Color" , size = 18),
	ColorPicker(ThemeColors , 4 , page)
	]))
	
	col.controls.extend([
	topAppBar,
	themeMode,
	themeFont,
	themeCol
	])
	
	return View(
		route="/settings/theme",
		controls = [col]
		)