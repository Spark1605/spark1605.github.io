from flet import *
from utils.DataManager import DataObj

themeObj = DataObj("data/theme.json")

class NavBar(Container):
	def __init__(self , page):
		super().__init__()
		self.page = page
		
		self.animate = animation.Animation(200 , AnimationCurve.DECELERATE)
		self.padding = 6
		self.border_radius = 8
		self.bgcolor = colors.with_opacity(0.18 , colors.ON_PRIMARY)
		self.border = border.all(1, colors.with_opacity(0.15 , colors.ON_SURFACE))
		self.gradient = LinearGradient(
	begin=alignment.top_left,
	end=alignment.bottom_right,
	colors= [colors.PRIMARY, colors.TERTIARY , colors.PRIMARY])
		
		self.NavItems = [
		self.NavItem(icons.HOME_ROUNDED , self.changeNav , "/"),
		self.NavItem(icons.INSERT_DRIVE_FILE_ROUNDED , self.changeNav , "/docs"),
		self.NavItem(icons.TIMER_ROUNDED, self.changeNav , "/stats"),
		self.NavItem(icons.SETTINGS_ROUNDED , self.changeNav , "/settings")
		]
		
		row = Row(self.NavItems , alignment = MainAxisAlignment.SPACE_BETWEEN)
		self.content = row
	
	def changeNav(self , e):
		for item in self.NavItems:
			item.icon_color = colors.ON_SURFACE
		e.control.icon_color = colors.PRIMARY
		self.page.go(e.control.data)
	
	def NavItem(self , icon , func , route):
		is_active = self.page.route == route
		
		return IconButton(
		icon = icon,
		on_click = func,
		icon_color = colors.PRIMARY if is_active else colors.ON_SURFACE,
		icon_size = 28,
		data = route
		)