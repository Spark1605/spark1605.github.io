class Syllabus:
	def __init__(self , sub = "Physics"):
		self.subject = sub
	
	def set(self , data = {}):
		...
	
	def get(self , key):
		...
	
	def update(self , key):
		...