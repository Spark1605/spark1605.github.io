import flet_fastapi
import uvicorn
from flet import *

#UTILITY
from utils.DataManager import DataObj
from utils.TimeManager import TimeManager

#COMPONENTS
from components.BSheet import BSheet
from components.Customs import Loader

#VIEWS
from views.home import home_view , add_record_view
from views.docs import docs_view
from views.stats import stats_view
from views.settings import settings_view, theme_view

themeObj = DataObj("data/theme.json")

def main(page: Page):
	page.session.set("is_dark" , themeObj.read()["dark"])
	page.session.set("themeColor" , themeObj.read()["themeColor"])
	page.session.set("themeFont" , themeObj.read()["themeFont"])
	
	page.title = "Stuco"
	page.theme_mode = ThemeMode.DARK if page.session.get("is_dark") else ThemeMode.LIGHT
	page.bgcolor = "#000000" if page.session.get("is_dark") else "#ffffff"
	page.theme = Theme(
	color_scheme_seed = page.session.get("themeColor"),
	font_family = page.session.get("themeFont"))
	page.padding = 5
	
	page.fonts = {
	"ariana": "fonts/ariana_violeta.ttf",
	"believe": "fonts/believe_it.ttf",
	"curly" : "fonts/cur_ly.ttf",
	"arial" : "fonts/arial.ttf"
	}
	views_map = {
		"/": home_view,
		"/add_record" : add_record_view,
		"/docs": docs_view,
		"/stats": stats_view,
		"/settings": settings_view,
		"/settings/theme" : theme_view
	}
	
	def route_change(e):
		page.views.clear()
		view_exists = views_map.get(page.route)
		
		if view_exists:
			page.views.append(view_exists(page))
		else:
			page.views.append(home_view(page))
		
		page.update()
	
	def view_pop(e):
		page.views.pop()
		top_view = page.views[-1]
		page.go(top_view.route)
	
	page.bottom_sheet = BottomSheet(BSheet(page))
	page.loader = Loader(page)
	
	page.on_route_change = route_change
	page.on_view_pop = view_pop
	
	page.overlay.append(page.loader)
	
	page.go(page.route)

app = flet_fastapi.app(main , assets_dir = "/storage/emulated/0/APyProject/Apps_Flet/Stuco/assets")

if __name__ == "__main__":
	uvicorn.run(app, host="127.0.0.1", port=8000)